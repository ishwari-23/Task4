import React from 'react';
import './contact.css'
const Contact = () => {
  return (
    <div>
      <section className="contact-section" >
        <div className="container" >
          <h1>Contact Us</h1><br/><br />
          <p>Have any questions? We'd love to hear from you! Reach out to us using the form below.</p>

          <form id="contactForm" action="#" method="POST">
            <div className="form-group">
              <label htmlFor="name">Full Name:</label>
              <input type="text" id="name" name="name" placeholder="Enter your full name" required />
            </div>
            <div className="form-group">
              <label htmlFor="email">Email Address:</label>
              <input type="email" id="email" name="email" placeholder="Enter your email" required />
            </div>
            <div className="form-group">
              <label htmlFor="message">Message:</label>
              <textarea id="message" name="message" rows="5" placeholder="Your message..." required></textarea>
            </div>
            <button type="submit" className="submit-btn">Send Message</button>
          </form>
        </div>
      </section>

    {/* Featured Dishes */}
  <footer class="footer">
  <div class="container">
    <p>&copy; 2025 Foodie Haven. All rights reserved.</p>
    <p class="footer-note">Made with love for food lovers everywhere.</p>
    <p>Made with 💗 <a href='https://www.linkedin.com/in/sakshi-yemul-7aa290344?'>Sakshi Yemul</a></p>
  </div>
  </footer>
    </div>
  );
};

export default Contact;
