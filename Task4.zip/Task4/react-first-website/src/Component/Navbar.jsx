import React from 'react'
import './Navbar.css'
import {Link} from 'react-router-dom'
const Navbar = () => {
  return (
    <>
        <nav>
            <h1>Foodie</h1>
            <ul>
                <li><Link style={{textDecoration:'none',color:'black',fontWeight:'bold',fontFamily:'Arial-black'}} to='/'>Home</Link></li>
                <li><Link style={{textDecoration:'none',color:'black',fontWeight:'bold',fontFamily:'Arial-black'}} to='/about'>About</Link></li>
                <li><Link style={{textDecoration:'none',color:'black',fontWeight:'bold',fontFamily:'Arial-black'}} to='/explore'>Explore</Link></li>
                <li><Link style={{textDecoration:'none',color:'black',fontWeight:'bold',fontFamily:'Arial-black'}} to='/contact'>Contact</Link></li>
            </ul>
        </nav>
        
    </>
  )
}

export default Navbar